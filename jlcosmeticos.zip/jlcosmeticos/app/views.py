from django.shortcuts import render
from .models import Produto
def home(request):
    Produtos = Produto.objects.all()
    return render(request,'home.html' , {'produtos' : Produtos})